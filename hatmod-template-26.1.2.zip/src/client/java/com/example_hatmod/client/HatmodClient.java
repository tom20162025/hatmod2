package com.example_hatmod.client;

import net.fabricmc.api.ClientModInitializer;

public class HatmodClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		// This entrypoint is suitable for setting up client-specific logic, such as rendering.
	}
}